**@WebParam **

注释用于定制从单个参数至 Web Service 消息部件和 XML 元素的映射。

  


将此注释应用于客户机或服务器服务端点接口（SEI）上的方法，或者应用于 JavaBeans 端点的服务器端点实现类。

  


**1、name ：**

参数的名称。如果操作是远程过程调用（RPC）类型并且未指定partName 属性，那么这是用于表示参数的 wsdl:part 属性的名称。

  


如果操作是文档类型或者参数映射至某个头，那么 -name 是用于表示该参数的 XML 元素的局部名称。如果操作是文档类型、

  


参数类型为 BARE 并且方式为 OUT 或 INOUT，那么必须指定此属性。（字符串）   

  


**2、partName：**

定义用于表示此参数的 wsdl:part属性的名称。仅当操作类型为 RPC 或者操作是文档类型并且参数类型为BARE 时才使用此参数。（字符串）

  


**3、targetNamespace：**

指定参数的 XML 元素的 XML 名称空间。当属性映射至 XML 元素时，仅应用于文档绑定。缺省值为 Web Service 的 targetNamespace。（字符串）

  


**4、mode：**

此值表示此方法的参数流的方向。有效值为 IN、INOUT 和 OUT。（字符串）

  


**5、header：**

指定参数是在消息头还是消息体中。缺省值为 false。（布尔值）

