**@WebMethod **

注释表示作为一项 Web Service 操作的方法，将此注释应用于客户机或服务器服务端点接口（SEI）上的方法，或者应用于 JavaBeans 端点的服务器端点实现类。

  


要点：

  


仅支持在使用 @WebService 注释来注释的类上使用 @WebMethod 注释

  


**1、operationName**

：指定与此方法相匹配的wsdl:operation 的名称。缺省值为 Java 方法的名称。（字符串）

  


**2、action：**

定义此操作的行为。对于 SOAP 绑定，此值将确定 SOAPAction 头的值。缺省值为 Java 方法的名称。（字符串）

  


**3、exclude：**

指定是否从 Web Service 中排除某一方法。缺省值为 false。（布尔值）  

  


**@Oneway **

注释将一个方法表示为只有输入消息而没有输出消息的 Web Service 单向操作。

  


将此注释应用于客户机或服务器服务端点接口（SEI）上的方法，或者应用于 JavaBeans 端点的服务器端点实现类  

