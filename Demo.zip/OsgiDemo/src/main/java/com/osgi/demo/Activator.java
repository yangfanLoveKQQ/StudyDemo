
package com.osgi.demo;

import org.osgi.framework.BundleActivator;
import org.osgi.framework.BundleContext;
import org.osgi.framework.FrameworkUtil;
import org.osgi.framework.ServiceReference;

/**
 * @author yangfan16
 *
 */
public class Activator implements BundleActivator {

    /*
     * (non-Javadoc)
     * 
     * @see org.osgi.framework.BundleActivator#start(org.osgi.framework.BundleContext)
     */
    public void start(BundleContext context) throws Exception {
        System.out.println("Hello");
        new RelatedFolderMonitorLoader().start();
    }

    /*
     * (non-Javadoc)
     * 
     * @see org.osgi.framework.BundleActivator#stop(org.osgi.framework.BundleContext)
     */
    public void stop(BundleContext context) throws Exception {
        System.out.println("Bye");
    }

}


class RelatedFolderMonitorLoader extends Thread {
    @Override
    public void run() {
        try {
            Thread.sleep(3000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        BundleContext context = FrameworkUtil.getBundle(Activator.class).getBundleContext();
        final ServiceReference<?> jobHandlerReference =
                context.getServiceReference(JobHandler.class.getName());
        final JobHandler jobHandler = (JobHandler) context.getService(jobHandlerReference);
        jobHandler.handler();
    }
}
