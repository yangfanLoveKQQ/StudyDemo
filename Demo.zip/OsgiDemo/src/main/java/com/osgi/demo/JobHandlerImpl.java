
package com.osgi.demo;

/**
 * @author yangfan16
 *
 */
public class JobHandlerImpl implements JobHandler {

    /* (non-Javadoc)
     * @see com.osgi.demo.jobHandler#handler()
     */
    public void handler() {
        System.out.println("Hello World!");
    }

}
