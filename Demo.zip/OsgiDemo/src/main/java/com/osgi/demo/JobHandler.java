
package com.osgi.demo;

/**
 * @author yangfan16
 *
 */
public interface JobHandler {

    void handler();
}
