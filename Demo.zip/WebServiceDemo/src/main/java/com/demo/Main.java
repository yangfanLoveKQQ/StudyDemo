
package com.demo;

import javax.xml.ws.Endpoint;

/**
 * @author yangfan16
 *
 */
public class Main {
    public static void main(String[] args) {
        System.out.println("web service start");
        HelloWorldImpl implementor= new HelloWorldImpl();
        String address="http://localhost:8080/HelloWorldService";
        Endpoint.publish(address, implementor);
        System.out.println("web service started");
        // 打开http://localhost:8080/HelloWorldService?wsdl
    }
}
