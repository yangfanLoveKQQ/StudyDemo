
package com.demo;

import org.apache.cxf.jaxws.JaxWsProxyFactoryBean;

/**
 * @author yangfan16
 *
 */
public class HelloWorldClient {

    /**
     * @param args
     */
    public static void main(String[] args) {
        JaxWsProxyFactoryBean svr = new JaxWsProxyFactoryBean();
        svr.setServiceClass(HelloWorld.class);
        svr.setAddress("http://localhost:8080/HelloWorldService");
        HelloWorld hw = (HelloWorld) svr.create();
        System.out.println(hw.sayHi("yangfan"));
    }

}
