package com.demo;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebResult;
import javax.jws.WebService;
import javax.xml.ws.RequestWrapper;
import javax.xml.ws.ResponseWrapper;

/**
 * @author yangfan16
 *
 */
@WebService(targetNamespace="HelloWorld.demo")
public interface HelloWorld {
    @WebMethod(operationName = "SayHi")
    @RequestWrapper(localName = "SayHiRequest")
    @ResponseWrapper(localName = "SayHiResponse")
    @WebResult(name = "SayHiResponseData")
    String sayHi(@WebParam(name = "Text") String text);
}
