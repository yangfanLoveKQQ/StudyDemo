
package com.demo;

import javax.jws.WebService;

/**
 * @author yangfan16
 *
 */
@WebService(serviceName = "HelloWorldService", endpointInterface = "com.demo.HelloWorld",
        targetNamespace = "HelloWorld.demo")
public class HelloWorldImpl implements HelloWorld {

    /*
     * (non-Javadoc)
     * 
     * @see com.demo.HelloWorld#sayHi(java.lang.String)
     */
    @Override
    public String sayHi(String text) {
        return "Hello " + text;
    }

}
